package ch08;

public class MyApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyFrame mf3 = new MyFrame();
	}

}
