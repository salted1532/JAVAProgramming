package ch08;
import javax.swing.*;

public class MyFrame2 extends JFrame{
	
	
	public static void main(String[] args) {
		MyFrame2 mf2 = new MyFrame2();
		mf2.setTitle("두번째 프레임입니다.");
		mf2.setSize(500, 500);
		mf2.setVisible(true);
	}

}
