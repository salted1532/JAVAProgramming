package ch10;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import ch10.CheckBoxitemEventEx.MyItemListener;

public class JComponentEx extends JFrame {
	
	private JCheckBox [] fruits = new JCheckBox [3];
	private String [] names = {"사과", "배", "체리"};
	private JLabel sumLabel;
	
	public JComponentEx() {
		super("JComponent의 공통 메소드 예제");
		Container c = getContentPane();
		c.setLayout(new FlowLayout());
		JButton b1 = new JButton("Magenta/Yellow Button");
		JButton b2 = new JButton(" Disabled Button ");
		JButton b3 = new JButton("getX(), getY()");
		b1.setBackground(Color.YELLOW); // 배경색 설정
		b1.setForeground(Color.RED); // 글자색 설정
		b1.setFont(new Font("Arial", Font.ITALIC, 20)); // Arial, 20픽셀 폰트 설정
		b2.setEnabled(false); // 버튼 비활성화
		b1.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setTitle("JComponent의 공통 메소드 예제"); // 타이틀에 버튼 좌표 출력
			}
		});
		
		b3.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton b = (JButton)e.getSource();
				setTitle(b.getX() + "," + b.getY()); // 타이틀에 버튼 좌표 출력
			}
		});
		
		JLabel textLabel = new JLabel("제임스 고슬링 입니다.");
		ImageIcon beauty = new ImageIcon("images/gosling.jpg");
		JLabel imageLabel = new JLabel(beauty);
		ImageIcon normalIcon = new ImageIcon("images/icon.gif");
		JLabel label = new JLabel("커피한잔 하실래예, 전화주이소", normalIcon, SwingConstants.CENTER);

		ImageIcon phonenormalIcon = new ImageIcon("images/normalIcon.gif");
		ImageIcon rolloverIcon = new ImageIcon("images/rolloverIcon.gif");
		ImageIcon pressedIcon = new ImageIcon("images/pressedIcon.gif");
		JButton btn = new JButton("call~~", phonenormalIcon);
		btn.setPressedIcon(pressedIcon);
		btn.setRolloverIcon(rolloverIcon);

		JCheckBox apple = new JCheckBox("사과", true);
		JCheckBox pear = new JCheckBox("배");
		JCheckBox cherry = new JCheckBox("체리");
		
		c.add(b1); // 컨텐트팬에 버튼 부착
		c.add(b2);
		c.add(b3);
		
		c.add(textLabel);
		c.add(imageLabel);
		c.add(label);
		
		c.add(btn);
		
		c.add(apple);
		c.add(pear);
		c.add(cherry);
		
		c.add(new JLabel("사과 100원, 배 500원, 체리 20000원"));
		MyItemListener listener = new MyItemListener();
		for(int i=0; i<fruits.length; i++) {
			fruits[i] = new JCheckBox(names[i]);
			fruits[i].setBorderPainted(true);
			c.add(fruits[i]);
			fruits[i].addItemListener(listener);
		}
		sumLabel = new JLabel("현재 0 원 입니다.");
		c.add(sumLabel);
		setSize(400,700);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	class MyItemListener implements ItemListener {
		private int sum = 0; // 가격의 합
		public void itemStateChanged(ItemEvent e) {
			if(e.getStateChange() == ItemEvent.SELECTED) {
				if(e.getItem() == fruits[0]) {
					sum += 100;
				} else if(e.getItem() == fruits[1]) {
					sum += 500;
				} else {
					sum += 20000;
				}
			}
			else if(e.getStateChange() == ItemEvent.DESELECTED){
				if(e.getItem() == fruits[0]) {
					sum -= 100;
				} else if(e.getItem() == fruits[1]) {
					sum -= 500;
				} else {
					sum -= 20000;
				}
			}
			sumLabel.setText("현재 "+ sum + "원 입니다.");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JComponentEx();
	}

}
