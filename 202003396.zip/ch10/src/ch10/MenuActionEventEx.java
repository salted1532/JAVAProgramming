package ch10;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.File;
import java.util.Random;

public class MenuActionEventEx extends JFrame{
	
	private JLabel imgLabel = new JLabel(); // 빈 레이블
	
    // 폴더 경로 설정
    File imagesFolder = new File("images");

    // 폴더 안의 파일 목록을 가져오기
    File[] files = imagesFolder.listFiles();
	
	public MenuActionEventEx() {
		setTitle("Menu에 Action 리스너 만들기 예제");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		createMenu();
		getContentPane().add(imgLabel, BorderLayout.CENTER);
		setSize(400,400); setVisible(true);
		imgLabel.setIcon(new ImageIcon("images/img.jpg"));
	}
	public void createMenu() {
		JMenuBar mb = new JMenuBar(); // 메뉴바 생성
		JMenuItem [] menuItem = new JMenuItem [4];
		String[] itemTitle = {"Load", "Hide", "ReShow", "Exit"};
		JMenu screenMenu = new JMenu("Screen");
		MenuActionListener listener = new MenuActionListener();
		for(int i=0; i<menuItem.length; i++) {
			menuItem[i] = new JMenuItem(itemTitle[i]);
			menuItem[i].addActionListener(listener);
			screenMenu.add(menuItem[i]);
		}
		mb.add(screenMenu);
		setJMenuBar(mb); // 메뉴바를 프레임에 부착
	}
	class MenuActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			String cmd = e.getActionCommand();
			
			switch(cmd) { // 메뉴 아이템의 종류 구분
			case "Load" :
				if(imgLabel.getIcon() != null) {
					 if (files != null && files.length > 0) {
				            // 랜덤으로 파일 선택
				            Random rand = new Random();
				            File randomFile = files[rand.nextInt(files.length)];
				            
				            ImageIcon icon = new ImageIcon(randomFile.getAbsolutePath());
				            
							imgLabel.setVisible(true);
							imgLabel.setIcon(icon);
					 } // 이미 로딩되었으면 리턴
				} else {
					return;
				}
			break;
			case "Hide" :
				imgLabel.setVisible(false); break;
			case "ReShow" :
				imgLabel.setVisible(true); break;
			case "Exit" :
				System.exit(0); break;
			}
		}
	}
	
	public static void main(String [] args) {

		new MenuActionEventEx();
	}
}
